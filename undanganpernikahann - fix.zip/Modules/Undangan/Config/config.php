<?php

return [
    'name' => 'Undangan'
];
