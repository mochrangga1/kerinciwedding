<?php

return [
    'name' => 'Client'
];
